#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist

def move_jackal():
    rospy.init_node('jackal_controller', anonymous=True)
    pub = rospy.Publisher('/jackal_velocity_controller/cmd_vel', Twist, queue_size=10)
    rate = rospy.Rate(30)  # 30 Hz

    forward_duration = rospy.Duration(10.0)  # Duration to move forward
    turn_duration = rospy.Duration(3.0)  # Duration to turn

    while not rospy.is_shutdown():
        # Move forward
        cmd_vel = Twist()
        cmd_vel.linear.x = 10.0  # Forward linear velocity
        pub.publish(cmd_vel)
        #rospy.sleep(forward_duration)

        # # Stop
        # cmd_vel = Twist()
        # pub.publish(cmd_vel)
        # rospy.sleep(1.0)  # Pause for a moment

        # Turn right
        cmd_vel.angular.z = 1.0  # Clockwise angular velocity
        pub.publish(cmd_vel)
        rospy.sleep(turn_duration)

        # # Stop
        # cmd_vel = Twist()
        # pub.publish(cmd_vel)
        # rospy.sleep(1.0)  # Pause for a moment

        # # Move forward
        # cmd_vel = Twist()
        # cmd_vel.linear.x = 1.0  # Forward linear velocity
        # pub.publish(cmd_vel)
        # rospy.sleep(forward_duration)

        # # Stop
        # cmd_vel = Twist()
        # pub.publish(cmd_vel)
        # rospy.sleep(1.0)  # Pause for a moment

        # # Turn left
        # cmd_vel.angular.z = 1.0  # Counter-clockwise angular velocity
        # pub.publish(cmd_vel)
        # rospy.sleep(turn_duration)

        # # Stop
        # cmd_vel = Twist()
        # pub.publish(cmd_vel)
        # rospy.sleep(1.0)  # Pause for a moment

    # Stop at the end
    cmd_vel = Twist()
    pub.publish(cmd_vel)

if __name__ == '__main__':
    try:
        move_jackal()
    except rospy.ROSInterruptException:
        pass
