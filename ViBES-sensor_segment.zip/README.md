# ViBES
Vision Based Environmental Sensing for Iot4Ag
 
