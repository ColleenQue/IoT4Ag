// Auto-generated. Do not edit!

// (in-package sensor_segment.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ContourSize {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.contour_size = null;
    }
    else {
      if (initObj.hasOwnProperty('contour_size')) {
        this.contour_size = initObj.contour_size
      }
      else {
        this.contour_size = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ContourSize
    // Serialize message field [contour_size]
    bufferOffset = _serializer.float64(obj.contour_size, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ContourSize
    let len;
    let data = new ContourSize(null);
    // Deserialize message field [contour_size]
    data.contour_size = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'sensor_segment/ContourSize';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '829cf93652b00363c95bdd4b6170fb3f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 contour_size
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ContourSize(null);
    if (msg.contour_size !== undefined) {
      resolved.contour_size = msg.contour_size;
    }
    else {
      resolved.contour_size = 0.0
    }

    return resolved;
    }
};

module.exports = ContourSize;
