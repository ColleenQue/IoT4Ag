// Auto-generated. Do not edit!

// (in-package sensor_segment.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let ContourSize = require('./ContourSize.js');

//-----------------------------------------------------------

class ContourSizeList {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.contour_size_list = null;
    }
    else {
      if (initObj.hasOwnProperty('contour_size_list')) {
        this.contour_size_list = initObj.contour_size_list
      }
      else {
        this.contour_size_list = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ContourSizeList
    // Serialize message field [contour_size_list]
    // Serialize the length for message field [contour_size_list]
    bufferOffset = _serializer.uint32(obj.contour_size_list.length, buffer, bufferOffset);
    obj.contour_size_list.forEach((val) => {
      bufferOffset = ContourSize.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ContourSizeList
    let len;
    let data = new ContourSizeList(null);
    // Deserialize message field [contour_size_list]
    // Deserialize array length for message field [contour_size_list]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.contour_size_list = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.contour_size_list[i] = ContourSize.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 8 * object.contour_size_list.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'sensor_segment/ContourSizeList';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '04263be13a911792a36869cf3f8b97bd';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    ContourSize[] contour_size_list
    ================================================================================
    MSG: sensor_segment/ContourSize
    float64 contour_size
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ContourSizeList(null);
    if (msg.contour_size_list !== undefined) {
      resolved.contour_size_list = new Array(msg.contour_size_list.length);
      for (let i = 0; i < resolved.contour_size_list.length; ++i) {
        resolved.contour_size_list[i] = ContourSize.Resolve(msg.contour_size_list[i]);
      }
    }
    else {
      resolved.contour_size_list = []
    }

    return resolved;
    }
};

module.exports = ContourSizeList;
