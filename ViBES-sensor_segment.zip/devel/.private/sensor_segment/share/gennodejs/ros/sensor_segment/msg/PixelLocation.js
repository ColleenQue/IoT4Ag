// Auto-generated. Do not edit!

// (in-package sensor_segment.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class PixelLocation {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.pixel_location_xy = null;
    }
    else {
      if (initObj.hasOwnProperty('pixel_location_xy')) {
        this.pixel_location_xy = initObj.pixel_location_xy
      }
      else {
        this.pixel_location_xy = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PixelLocation
    // Serialize message field [pixel_location_xy]
    bufferOffset = _arraySerializer.float64(obj.pixel_location_xy, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PixelLocation
    let len;
    let data = new PixelLocation(null);
    // Deserialize message field [pixel_location_xy]
    data.pixel_location_xy = _arrayDeserializer.float64(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 8 * object.pixel_location_xy.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'sensor_segment/PixelLocation';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7887fc0fb1b9ed863439209539bb7cbe';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64[] pixel_location_xy
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PixelLocation(null);
    if (msg.pixel_location_xy !== undefined) {
      resolved.pixel_location_xy = msg.pixel_location_xy;
    }
    else {
      resolved.pixel_location_xy = []
    }

    return resolved;
    }
};

module.exports = PixelLocation;
