#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
from gazebo_msgs.msg import ModelStates
import numpy as np
import math
from itertools import product

class SquareMove:
    def __init__(self):
        print("[SquareMove Node] Initializing ...")
        rospy.init_node("square_move", anonymous=False)

        self.rate = rospy.Rate(1)
        self.current_position_x,self.current_position_y=None,None
        self.current_goal = None

        #self.current_index =0
        #self.waypoints("horizontal",5)
        #self.current_goal = self.waypoint_list[self.current_index]
        
   
        self.sub  = rospy.Subscriber('/gazebo/model_states', ModelStates,self. model_states_callback,queue_size=1)

        self.pub = rospy.Publisher('/jackal_velocity_controller/cmd_vel', Twist, queue_size=1)

        rospy.spin()


    def model_states_callback(self, msg):    
    
        print("subuscribing------------------------------------")
        last_model_pose = msg.pose[-1]

        #get current position
        self.current_position_x = last_model_pose.position.x
        self.current_position_y = last_model_pose.position.y
        #get current angle
        self.quaternion = last_model_pose.orientation
        self.current_angle = self.quaternion_to_radians()

        self.perform_action()


    



    def perform_action(self):
        #start in a corner if not intialized

        
        if not self.current_goal: self.current_closest()
        #print("curr goal", self.current_goal)

        self.goal_position_x = self.current_goal[0]
        self.goal_position_y = self.current_goal[1]

        self.distance_x = self.goal_position_x  - self.current_position_x
        self.distance_y = self.goal_position_y- self.current_position_y
        distance = self.Pythagorean()

        if distance < 0.2:
            #go to the next goal
            self.nextpoint()
            #self.current_index +=1
            #self.current_goal = self.waypoint_list[self.current_index]


        ##### angle    
        #calculate desired goal angle based on distance_x and distance_y
        self.goal_angle = math.atan2(self.distance_y,self.distance_x)
        angle = self.goal_angle - self.current_angle


        #edge case where self.goal_angle and current_angle are closer to 3.14
        # #that is when abs(goal) + abs(current) > pi and goal*current <0
        if abs(self.current_angle)+abs(self.goal_angle)>math.pi and self.current_angle*self.goal_angle<0:
            angle = -1/angle


        #### assign angular and linear velocity so the robot moves
        cmd_vel = Twist()
        if abs(angle) <= 0.1:
            #move only if angle is correct
            cmd_vel.linear.x = distance*2
        else:
            cmd_vel.linear.x = 0

        cmd_vel.angular.z = angle*2

        #move
        self.pub.publish(cmd_vel)

    def current_closest(self):
        #assign robot to the closest station
        x= 9.9*np.sign(self.current_position_x)
        y = 9.9*np.sign(self.current_position_y)
        self.current_goal = [x,y]
        #determine go left or go right
        if y == 9.9:
            self.direction = "left"
        else:
            self.direction = "right"

    def quaternion_to_radians(self):
        # Extract the x, y, and z components of the quaternion
        x = self.quaternion.x
        y = self.quaternion.y
        z = self.quaternion.z
        w = self.quaternion.w

        yaw = math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))

        return yaw
    

    def Pythagorean(self):
        # Calculate the differences in x and y coordinates
        
        # Calculate the square of the differences
        dx_squared = self.distance_x  ** 2
        dy_squared = self.distance_y ** 2

        # Calculate the sum of the squares
        sum_of_squares = dx_squared + dy_squared

        # Calculate the square root of the sum of squares
        distance = math.sqrt(sum_of_squares)

        return distance
    
    def nextpoint(self):
        #given current goal location, find the next goal

        #if distance < 0.2:
        if self.current_goal[1] == 9.9:
            self.direction = "left"
        elif self.current_goal[1] == -9.9:
            self.direction = "right"


        if (self.current_goal[0] == 9.9 and abs(self.current_goal[1])==4.95):
            #move up: update x axis
            self.current_goal[0] = -9.9
        elif (self.current_goal[0] == -9.9 and abs(self.current_goal[1])!=4.95):
            #move down
            self.current_goal[0] = 9.9
        
        #move right:
        elif (self.current_goal[0]== -9.9 and abs(self.current_goal[1])==4.95) or (self.current_goal[0]== 9.9 and abs(self.current_goal[1])!=4.95 and (self.current_goal[1])!=9.9):
            if self.direction == "right":
                self.current_goal[1] += 4.95
            else:
                self.current_goal[1] -= 4.95

        #move left:
        else:
            if self.direction == "left":
                self.current_goal[1] -= 4.95
            else:
                self.current_goal[1] += 4.95


    def solve(self,l1, l2):
        return list(product(l1, l2))


    def waypoints(self,path,density):
        # parameters
        # horizontal or vertical path
        # density is proportional to the amount of turning points
        # return a set of waypoints 

        #for example, the total width = 9.9 * 2 = 19.8
        # 4.95 = 19.8/4
        len = 19.8/density
        self.res_x = []
        self.res_y = []


        if path == "horizontal":
            for i in range(density+1):
                #x takes the change
                self.res_x.append(-9.9+i*len)
                self.res_y = [-9.9,9.9]
        else:
            for i in range(density+1):
                #x takes the change
                self.res_y.append(-9.9+i*len)
                self.res_x = [-9.9,9.9]

            
        
    def change(self, long, short):
        #get the sequence from points x and points y
        #the short parameter = array with shorter points
        # 0,0 --> 1,0 --> 1,1 --> 0,1 --> 0,2 --> 1,2 --> 1,3 --> 0,3 --> 0,4
        # incr --> 0  -> 1 -> 0 -> 1
        i = 0
        res = []
        tup = (0,0)


if __name__ == "__main__":
    node = SquareMove()
    while not rospy.is_shutdown():
        node.rate.sleep()




