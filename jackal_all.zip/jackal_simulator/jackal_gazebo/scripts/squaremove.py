#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
from gazebo_msgs.msg import ModelStates
import numpy as np
import math


class SquareMove:
    def __init__(self):
        print("[SquareMove Node] Initializing ...")
        rospy.init_node("square_move", anonymous=False)

        self.rate = rospy.Rate(1)
        self.current_position_x,self.current_position_y=None,None


        #hard coded goal position = [-10,-10]
        #initial position = [-10,10]
        #point A --> point B and so on
        self.goals = {(9.9,-9.9):(9.9,9.9),(9.9,9.9):(-9.9,9.9),(-9.9,9.9):(-9.9,-9.9),(-9.9,-9.9):(9.9,-9.9)}

        #move to the closest current
        self.current_goal = (-9.9,9.9)
   
        self.sub  = rospy.Subscriber('/gazebo/model_states', ModelStates,self. model_states_callback,queue_size=1)
        self.pub = rospy.Publisher('/jackal_velocity_controller/cmd_vel', Twist, queue_size=1)

        rospy.spin()


    def model_states_callback(self, msg):    
    
        print("subuscribing------------------------------------")
        last_model_pose = msg.pose[-1]

        self.current_position_x = last_model_pose.position.x
        self.current_position_y = last_model_pose.position.y

        #move to the closest current


        self.quaternion = last_model_pose.orientation
        self.current_angle = self.quaternion_to_radians()
        print(self.current_angle)


        #1: goal = 10, -10
        #2: goal = 10, 10 

        print(last_model_pose.position.x)
        print(last_model_pose.position.y)
        # print("z",self.current_angle_z)
        # print("w",self.current_angle_w)

        self.perform_action()


    def perform_action(self):

        self.goal_position_x = self.current_goal[0]
        self.goal_position_y = self.current_goal[1]

        self.distance_x = self.goal_position_x  - self.current_position_x
        self.distance_y = self.goal_position_y- self.current_position_y

        print(self.current_goal)


        distance = self.Pythagorean()
        print("distance",distance)
        if distance < 0.2:
            #go to the next goal
            self.current_goal = self.goals[self.current_goal]

        #calculate desired goal angle based on distance_x and distance_y
        self.goal_angle = math.atan2(self.distance_y,self.distance_x)

        angle = self.goal_angle - self.current_angle



        #edge case where self.goal_angle and current_angle are closer to 3.14
        # #that is when abs(goal) + abs(current) > pi and goal*current <0
        if abs(self.current_angle)+abs(self.goal_angle)>math.pi and self.current_angle*self.goal_angle<0:
            angle = -1/angle

        print(angle)


        cmd_vel = Twist()
        if abs(angle) <= 0.1:
            #move if angle is correct
            cmd_vel.linear.x = distance*2
        else:
            cmd_vel.linear.x = 0

        cmd_vel.angular.z = angle*2
        self.pub.publish(cmd_vel)
            
    def stop_motion(self):
        cmd_vel = Twist()
        self.pub.publish(cmd_vel)

    def quaternion_to_radians(self):
        # Extract the x, y, and z components of the quaternion
        x = self.quaternion.x
        y = self.quaternion.y
        z = self.quaternion.z
        w = self.quaternion.w

        yaw = math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))

        return yaw
    

    def Pythagorean(self):
        # Calculate the differences in x and y coordinates
        
        # Calculate the square of the differences
        dx_squared = self.distance_x  ** 2
        dy_squared = self.distance_y ** 2

        # Calculate the sum of the squares
        sum_of_squares = dx_squared + dy_squared

        # Calculate the square root of the sum of squares
        distance = math.sqrt(sum_of_squares)

        return distance
    




if __name__ == "__main__":
    node = SquareMove()
    while not rospy.is_shutdown():
        node.rate.sleep()




