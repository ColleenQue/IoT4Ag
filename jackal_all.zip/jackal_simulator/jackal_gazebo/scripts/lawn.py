#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
import numpy as np
import math

def move_jackal():
    rospy.init_node('jackal_controller', anonymous=True)
    pub = rospy.Publisher('/jackal_velocity_controller/cmd_vel', Twist, queue_size=10)
    rate = rospy.Rate(1)  # 30 Hz

    forward_duration = rospy.Duration(2.0)  # Duration to move forward
    turn_duration = rospy.Duration(1.0)  # Duration for a 90-degree turn (adjust as needed)
    middle_duration = rospy.Duration(2.0) 

    while not rospy.is_shutdown():
        print(rospy.Time.now())
        #perform_action(pub, 1.0, 0.0, forward_duration,"forward")  # Move forward
        perform_action(pub, 0.0, -np.pi / 4, turn_duration,"turn")  # Turn 90 degrees
        #perform_action(pub, 1.0, 0.0, middle_duration)  # Move forward
        #perform_action(pub, 0.0, np.pi / 2, turn_duration)  # Turn 90 degrees
        #perform_action(pub, -1.0, 0.0, forward_duration)  # Move forward
        #perform_action(pub, 0.0, -math.pi / 2, turn_duration)  # Turn -90 degrees
        
        # Stop at the end
        stop_motion(pub)
        rate.sleep()
        
def quaternion_to_radians(self):
    # Extract the x, y, and z components of the quaternion
    x = self.quaternion.x
    y = self.quaternion.y
    z = self.quaternion.z
    w = self.quaternion.w

    yaw = math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))

    return yaw


def perform_action(pub, linear_vel, angular_vel, duration,debug):
    rate=rospy.Rate(1)
    print(debug)
    # Wait for the desired duration
    start_time = rospy.Time.now()
    while rospy.Time.now() - start_time < duration:
        #goes super fast
        
        cmd_vel = Twist()
        cmd_vel.linear.x = linear_vel
        cmd_vel.angular.z = angular_vel
        pub.publish(cmd_vel)
   

def stop_motion(pub):
    cmd_vel = Twist()
    pub.publish(cmd_vel)

if __name__ == '__main__':
    try:
        move_jackal()
    except rospy.ROSInterruptException:
        pass
