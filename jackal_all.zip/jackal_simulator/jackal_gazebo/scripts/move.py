#!/usr/bin/env python3
from itertools import product
def solve(l1, l2):
   return list(product(l1, l2))





def waypoints(path,density):
    # parameters
    # horizontal or vertical path
    # density is proportional to the amount of turning points
    # return a set of waypoints 

    #for example, the total width = 9.9 * 2 = 19.8
    # 4.95 = 19.8/4
    len = 19.8/density
    res_x = []
    res_y = []


    if path == "horizontal":
        for i in range(density+1):
            #x takes the change
            res_x.append(-9.9+i*len)
            res_y = [-9.9,9.9]


    else:
        for i in range(density+1):
            #x takes the change
            res_y.append(-9.9+i*len)
            res_x = [-9.9,9.9]

    return res_x,res_y


print(solve(waypoints("vertical",5)[1],waypoints("vertical",5)[0]))
